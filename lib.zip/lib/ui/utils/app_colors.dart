import 'package:flutter/material.dart';

class AppColors {
  static const Color themeColor = Colors.green;
}