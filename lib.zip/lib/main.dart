import 'package:flutter/cupertino.dart';
import 'package:task_management_app/app.dart';

void main(){
  runApp(const TaskManagerApp());
}